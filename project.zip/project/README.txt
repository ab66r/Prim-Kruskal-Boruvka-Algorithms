This is read me file for 14012402-4 Algorithms corse project

the programing languge that is beaing used is: Python 
-Python Libraries that is beaing used in the Python file codes are: pandas, numpy, time

the project folder consest of:
- three files for each data structure for the three algorithms:

   -AdjMatrix folder:consest of (BrouvkaAdjMatrix.py, kruskalAdjMatrix.py,  								    PrimeAdjMatrix.py, graph1)
     - BrouvkaAdjMatrix.py, kruskalAdjMatrix.py, PrimAdjMatrix.py are the code file for  		     each algorithms 
       using adjacency matrix.
     - graph1 is the part of the data that the coputer could handel.

   -AdjList folder: consest of (BrouvkaAdjList.py, kruskalAdjList.py, PrimeAdjList.py, graph1)
     - BrouvkaAdjList.py, kruskalAdjList.py, PrimAdjList.py are the code file for each algorithms 
       using adjacency List.
     - graph1 is the part of the data that the coputer could handel.

   -Graph folder: consest of (Brouvka.py, kruskal.py, Prime.py, graph1, Boruvka graph)
     - Brouvka.py, kruskal.py, Prime.py are the code file for each algorithms 
       using Graph.
     - graph1 is the part of the data that the coputer could handel 
     

- Graph: is the file of the big data for this project (witch graph1 took the data from).

- Report file.
