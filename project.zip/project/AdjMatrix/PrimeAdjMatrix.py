# Prim's Algorithm in Python

import time
import pandas as pd
import numpy as np

def Prime():
    no_edge = 0
    selected_node[0] = True
    # printing for edge and weight
    mst = 0
    while (no_edge < N - 1):
        minimum = I
        a = 0
        b = 0
        for m in range(N):
            if selected_node[m]:
                for n in range(N):
                    n = int(n)
                    if ((not selected_node[n]) and Graph[m][n] > 0):
                        # not in selected and there is an edge
                        if minimum > Graph[m][n]:
                            minimum = Graph[m][n]
                            a = m
                            b = n
        print(str(a) + "-" + str(b) + ":" + str(Graph[a][b]))
        mst += Graph[a][b]
        selected_node[b] = True
        no_edge += 1
    return mst

# creating graph by adjacency matrix method
def readFile():
    data = pd.read_csv("graph1.txt", sep="\t")
    data.columns = ["c1", "c2", "c3"]
    adj = np.zeros((data["c2"].max() , data["c2"].max()), dtype=np.float32)
    for i, j, z in zip(data['c1'].to_list(), data['c2'].to_list(), data['c3'].to_list()):
        adj[i - 1][j - 1] = z
    return adj

Graph = readFile()
I = 9999999
# number of vertices in graph
N = len(Graph)
selected_node = [0 for i in range(N)]
no_edge = 0
selected_node[0] = True
t = time.perf_counter()
mst = Prime()
print("\n*execution time :", time.perf_counter() - t)
print("*MST cost ", mst)
