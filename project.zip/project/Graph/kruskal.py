#Shahd 442006985

class Node: #Define a class "Node"  
  def __init__(self, val): # two attributes: "val" and "neighbors"
    self.val = val
    self.neighbors = []

import pandas as pd ##Read the graph data from a text file using pandas and store it in a dataframe
import numpy as np
data = pd.read_csv("g.txt", sep="\t",)
data.columns = ["N1", "N2","N3"] #The columns of the dataframe are named
n = data["N2"].max() ## maximum value of the second column and store it in a variable "n"
adjAray = -1*np.ones(shape=(n,n),dtype="object") #Create an empty 2D numpy array of size "n x n" called "adjAray"
graphNodes=[] #Create an empty list "graphNodes" which will store the nodes of the graph
for i in range(n):
  graphNodes.append(Node(i))
for i, j ,z in zip(data["N1"].to_list(), data["N2"].to_list(),data["N3"].to_list()):
    adjAray[i-1][j-1]=z
    adjAray[j-1][i-1]=z


for i in range(n):
  for j in range(n):
    if adjAray[i][j] !=-1:
      graphNodes[i].neighbors.append((graphNodes[j],adjAray[i][j]))

INF=float("inf")
parent = [i for i in range(len(graphNodes))]
# Find set of vertex i
def find(i): #Define a function "find(i)" that takes a vertex "i" and returns the set of the vertex
    while parent[i] != i:
        i = parent[i]
    return i

# Does union of i and j. It returns
# false if i and j are already in same
# set.
def union(i, j): #efine a function "union(i, j)" that takes two vertices "i" and "j" and returns the union of their sets
    a = find(i)
    b = find(j)
    parent[a] = b

print(len(graphNodes))
# Finds MST using Kruskal's algorithm
def kruskalMST(cost): # calculates the minimum cost 
    mincost = 0  # Cost of min MST

    # Initialize sets of disjoint sets
    for i in range(len(graphNodes)):
        parent[i] = graphNodes[i].val

    # Include minimum weight edges one by one
    edge_count = 0
    while edge_count < len(graphNodes) - 1:
        min = INF
        a = -1
        b = -1
        for i in graphNodes:
            for j in i.neighbors:
                if find(i.val) != find(j[0].val) and j[1] < min:
                    min = j[1]
                    a = i
                    b = j[0]
        if a!= -1 and b!=-1:
            union(a.val, b.val)
            print('Edge {}:({}, {}) cost:{}'.format(edge_count, a.val, b.val, min))

        if min != INF:
            mincost += min
        edge_count+=1

    print("Minimum cost= {}".format(mincost))
import time
t=time.perf_counter()
kruskalMST(graphNodes) #Call the "kruskalMST" function with the "graphNodes" list as input.
print("\nTime",time.perf_counter()-t)