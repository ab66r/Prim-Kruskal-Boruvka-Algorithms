#Shahd 442006985

class Node: #Define a class "Node"  
  def __init__(self, val):# two attributes: "val" and "neighbors"
    self.val = val #the identifier of the node
    self.neighbors = [] #is a list of pairs

import pandas as pd #Read the graph data from a text file using pandas and store it in a dataframe
import numpy as np 
data = pd.read_csv("g.txt", sep="\t",)
data.columns = ["N1", "N2","N3"] #The columns of the dataframe are named
n = data["N2"].max() # maximum value of the second column and store it in a variable "n"
adjAray = -1*np.ones(shape=(n,n),dtype="object") #Create an empty 2D numpy array of size "n x n" called "adjAray"
graphNodes=[]#Create an empty list "graphNodes" which will store the nodes of the graph
for i in range(n):
  graphNodes.append(Node(i))#For each value in the range "0 to n-1", create a new node with the value "i" and append it to the list "graphNodes"

for i, j ,z in zip(data["N1"].to_list(), data["N2"].to_list(),data["N3"].to_list()):
    adjAray[i-1][j-1]=z
    adjAray[j-1][i-1]=z

for i in range(n):
  for j in range(n):
    if adjAray[i][j] !=-1:
      graphNodes[i].neighbors.append((graphNodes[j],adjAray[i][j]))

I = 9999999
# number of vertices in graph
selected_node = [0 for i in range(len(graphNodes))]
no_edge = 0
selected_node[0] = True
import time

def Prime(): #Define a function named "Prime" to find the minimum spanning tree
    no_edge = 0
    selected_node[0] = True
    # printing for edge and weight
    print("Edge : Weight\n")
    mst = 0

    while (no_edge < len(graphNodes) - 1):

        minimum = I
        a = None
        b = None
        for m in graphNodes:
            if selected_node[graphNodes.index(m)]:
                for n in m.neighbors:

                    if ((not selected_node[graphNodes.index(n[0])]) and n[1]>0):
                        # not in selected and there is an edge
                        if minimum > n[1]:
                            minimum = n[1]
                            a = m
                            b = n



        if a != None and b != None:
            print(str(a.val) + "-" + str(b[0].val) + ":" + str(a.neighbors[a.neighbors.index(b)][1]))
            mst += a.neighbors[a.neighbors.index(b)][1]
            selected_node[graphNodes.index(b[0])] = True
        no_edge += 1 #Increment the number of edges, "no_edge", and continue the while loop
    print(mst)
t = time.perf_counter()
mst = Prime()
print("\n*time :", time.perf_counter() - t) #print the MST cost and the execution time
print("*MST cost ", mst)
